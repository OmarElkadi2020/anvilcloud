
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// backend/functions/contactform/contactform.mts
import serverlessHttp from "serverless-http";
import express from "express";
import nodemailer from "nodemailer";
import bodyParser from "body-parser";
import cors from "cors";
import morgan from "morgan";
import winston from "winston";
var contactform_default = (request, context) => {
  const app = express();
  app.use(cors());
  app.use(bodyParser.json());
  const logger = winston.createLogger({
    level: "info",
    format: winston.format.combine(
      winston.format.timestamp(),
      winston.format.json()
    ),
    transports: [
      new winston.transports.Console()
      // Optionally, add file transports:
      // new winston.transports.File({ filename: 'error.log', level: 'error' }),
      // new winston.transports.File({ filename: 'combined.log' })
    ]
  });
  app.use(morgan("combined", {
    stream: {
      write: (message) => logger.info(message.trim())
    }
  }));
  const transporter = nodemailer.createTransport({
    service: "gmail",
    // or another provider
    auth: {
      user: "elkadi.omar.oe@gmail.com",
      pass: "vfbexpwzunihtsxj"
    }
  });
  app.post("/contact", async (req, res) => {
    const { name, email, company, phone, inquiry, message } = req.body;
    logger.info("Received contact form submission", { name, email, company, phone, inquiry });
    const text = `We have received a new contact form submission. Here are the details:
  
                - Inquiry Type: ${inquiry}
                - Sender Name: ${name}
                - Sender Email: ${email}
                - Sender's Company: ${company}
                - Sender's Phone: ${phone}

                Message:
                ${message}`;
    const mailOptions = {
      from: "elkadi.omar.oe@gmail.com",
      to: "elkadi.omar.oe2@gmail.com",
      subject: `${inquiry} from ${name}`,
      text
    };
    const mailOptions2 = {
      from: "elkadi.omar.oe@gmail.com",
      to: "ti.ge.r@icloud.com",
      subject: `${inquiry} from ${name}`,
      text
    };
    try {
      await transporter.sendMail(mailOptions);
      await transporter.sendMail(mailOptions2);
      logger.info("Email sent successfully");
      res.status(200).json({ success: true, message: "Submission processed." });
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      logger.error("Error processing contact form submission", { error: errorMessage });
      res.status(500).json({ success: false, error: errorMessage });
    }
  });
  app.get("/", (req, res) => {
    res.send("Hello World!");
  });
  serverlessHttp(app);
};
export {
  contactform_default as default
};
